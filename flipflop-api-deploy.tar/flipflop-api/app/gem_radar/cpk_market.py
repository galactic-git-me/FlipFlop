"""Phase 1 of the CPK-driven market-price system: accumulate a market price
per Canonical Product Key from the listings actually seen, rather than from
an external benchmark source.

Design (per product spec): every listing that gets a CPK contributes its
price as a data point for that CPK — the median of prices seen across the
same product within and across vendors, over a rolling MARKET_PRICE_WINDOW_
DAYS window (not all-time unbounded: a price from 3 months ago shouldn't
still be dragging down today's median). The aggregate (min/median/max) is
always recomputed and stored, but a CPK's price is only trustworthy for
classification once 2+ listings within that window have contributed to it —
see get_market_price's is_settled gate and phase2_classify_by_market_price.py,
which is the only caller allowed to actually use these prices.

Deliberately no outlier removal here (per product spec, "remove the removal
of outliers for now") — every observed price within the window counts,
unfiltered.
"""
from __future__ import annotations

from dataclasses import dataclass

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

import structlog

log = structlog.get_logger(__name__)

# Below this many contributing listings, a CPK's aggregate price is not
# considered "settled" — see get_market_price.
MIN_LISTINGS_FOR_SETTLED_PRICE = 2

# Rolling window for market-price aggregation. A listing's row in
# gem_radar_cpk_listing_price is upserted on every re-sighting (its
# updated_at refreshes each time), so a listing that's still actively being
# scraped stays inside the window indefinitely — only genuinely stale,
# no-longer-seen listings age out.
MARKET_PRICE_WINDOW_DAYS = 14


async def get_robust_sold_market(
    db: AsyncSession,
    *,
    cpk: str,
    condition: str,
    subject_listing_id: str,
    policy,
    minimum_comps: int | None = None,
):
    """Return a same-condition completed-sale cohort only.

    Active BIN, Amazon and scan prices remain available elsewhere as context,
    but are intentionally excluded from realised resale value.
    """
    from dataclasses import replace
    from app.gem_radar.opportunity_scoring import SoldComparable, robust_sold_market

    normalised = "new" if (condition or "").lower() == "new" else "used"
    result = await db.execute(
        text(
            """
            SELECT price, postage, source_url,
                   EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - observed_at)) / 86400.0 AS days_ago
            FROM gem_radar_sold_observations
            WHERE cpk = :cpk
              AND LOWER(condition) = :condition
              AND observed_at >= CURRENT_TIMESTAMP - make_interval(days => :lookback)
              AND price > 0
            ORDER BY observed_at DESC
            """
        ),
        {"cpk": cpk, "condition": normalised, "lookback": policy.sold_lookback_days},
    )
    comps = [SoldComparable(float(r[0]), float(r[1] or 0), r[2], float(r[3] or 0)) for r in result.fetchall()]
    cohort_policy = replace(policy, minimum_sold_comps=minimum_comps) if minimum_comps is not None else policy
    return robust_sold_market(comps, subject_listing_id=subject_listing_id, policy=cohort_policy)


async def get_robust_active_market(
    db: AsyncSession,
    *,
    cpk: str,
    condition: str,
    subject_listing_id: str,
    policy,
):
    """Estimate achievable value from fresh, leave-one-out active prices.

    Active asking prices are not treated as realised sales: the robust lower
    quartile receives a condition-specific realisation haircut and a confidence
    penalty. This is the fallback classification anchor when sold coverage is
    unavailable, not a replacement for sold evidence.
    """
    from app.gem_radar.opportunity_scoring import SoldComparable

    normalised = "new" if (condition or "").lower() == "new" else "used"
    result = await db.execute(text("""
        WITH latest AS (
            SELECT DISTINCT ON (listing_id) listing_id, condition_normalised, source
            FROM gem_radar_listing_observations
            ORDER BY listing_id, observed_at DESC, id DESC
        )
        SELECT p.price, p.listing_id, l.source
        FROM gem_radar_cpk_listing_price p
        JOIN latest l ON l.listing_id = p.listing_id
        WHERE p.cpk = :cpk
          AND p.listing_id <> :subject
          AND p.updated_at >= CURRENT_TIMESTAMP - INTERVAL '14 days'
          AND CASE WHEN LOWER(COALESCE(l.condition_normalised, '')) = 'new' THEN 'new' ELSE 'used' END = :condition
          AND p.price > 0
    """), {"cpk": cpk, "subject": subject_listing_id, "condition": normalised})
    comps = [
        SoldComparable(float(price), source_url=f"{source or 'active'}://{listing_id}")
        for price, listing_id, source in result.fetchall()
    ]
    return robust_active_market(
        comps, subject_listing_id=subject_listing_id,
        condition=normalised, policy=policy,
    )


def robust_active_market(comps, *, subject_listing_id: str, condition: str, policy):
    from dataclasses import replace
    from statistics import median
    from app.gem_radar.opportunity_scoring import RobustMarket, SoldComparable, robust_sold_market

    active_policy = replace(policy, minimum_sold_comps=max(3, policy.minimum_sold_comps))
    fixed_retailers = {"amazon", "overclockers", "scan", "awd_it", "computer_orbit", "bargain_hardware", "cex"}
    marketplace_factor = 0.92 if condition == "new" else 0.88
    adjusted = []
    factors = []
    retail_count = 0
    for comp in comps:
        source = (comp.source_url or "").split("://", 1)[0].lower()
        factor = 1.0 if source in fixed_retailers else marketplace_factor
        retail_count += int(factor == 1.0)
        factors.append(factor)
        adjusted.append(SoldComparable(comp.price * factor, comp.postage * factor, comp.source_url, comp.observed_days_ago))
    market = robust_sold_market(adjusted, subject_listing_id=subject_listing_id, policy=active_policy)
    if market is None:
        # An exact fixed retailer price is a real purchasable transaction
        # price even when only one shop stocks the SKU. It establishes a
        # lower-confidence context tier, not GEM-quality evidence.
        fixed = [c for c in adjusted if (c.source_url or "").split("://", 1)[0].lower() in fixed_retailers and subject_listing_id.lower() not in (c.source_url or "").lower()]
        if not fixed:
            return None
        values = sorted(c.delivered_price for c in fixed if c.delivered_price > 0)
        if not values:
            return None
        mid = median(values)
        spread = ((max(values) - min(values)) / mid * 100.0) if mid else 100.0
        return RobustMarket(
            lower=round(min(values), 2), median=round(mid, 2), upper=round(max(values), 2),
            conservative_resale=round(min(values), 2), sample_size=len(values), raw_sample_size=len(values),
            source_diversity=len({_c.source_url for _c in fixed}), spread_pct=round(spread, 2),
            confidence=min(65.0, 35.0 + len(values) * 10.0),
            comparable_urls=tuple(c.source_url for c in fixed if c.source_url),
            basis="FIXED_RETAIL_CONTEXT", realisation_factor=1.0,
        )
    retail_share = retail_count / len(comps) if comps else 0.0
    factor = sum(factors) / len(factors) if factors else marketplace_factor
    basis = "FIXED_RETAIL_ESTIMATED" if retail_share == 1 else ("MIXED_ACTIVE_ESTIMATE" if retail_share > 0 else "BIN_ESTIMATED")
    confidence_penalty = 5.0 if retail_share >= 0.5 else 15.0
    return replace(
        market,
        confidence=round(max(0.0, market.confidence - confidence_penalty), 1),
        basis=basis, realisation_factor=round(factor, 3),
    )


@dataclass(frozen=True)
class CPKMarketPrice:
    cpk: str
    min_price: float
    median_price: float
    max_price: float
    listing_count: int


async def upsert_scan_price(
    db: AsyncSession,
    cpk: str | None,
    match_key: str,
    price: float,
    category: str | None = None,
    brand: str | None = None,
    model: str | None = None,
) -> None:
    """Records a barcode scan price observation for market-price aggregation.
    Scan prices are solid new retail prices (not used), providing a cross-vendor
    consensus point for new-condition items. If CPK is unavailable, the scan
    price still contributes via match_key lookup in the aggregation query."""
    from app.models.gem_radar_scan_observation import GemRadarScanObservation

    db.add(
        GemRadarScanObservation(
            cpk=cpk,
            match_key=match_key,
            price=price,
            category=category,
            brand=brand,
            model=model,
        )
    )
    await db.commit()


async def upsert_listing_price(
    db: AsyncSession,
    cpk: str,
    listing_id: str,
    price: float,
    category: str | None = None,
    brand: str | None = None,
    model: str | None = None,
) -> None:
    """Records/updates this listing's price as a data point for `cpk`, then
    recomputes and stores the CPK's min/median/max/listing_count from every
    listing currently on record for it. Idempotent — re-running for a
    listing_id already seen updates its price in place rather than double-
    counting it, so re-scraping the same still-live listing every scan cycle
    doesn't inflate listing_count.
    """
    await db.execute(
        text(
            """
            INSERT INTO gem_radar_cpk_listing_price (listing_id, cpk, price, updated_at)
            VALUES (:listing_id, :cpk, :price, CURRENT_TIMESTAMP)
            ON CONFLICT (listing_id) DO UPDATE SET
                cpk = EXCLUDED.cpk,
                price = EXCLUDED.price,
                updated_at = CURRENT_TIMESTAMP
            """
        ),
        {"listing_id": listing_id, "cpk": cpk, "price": price},
    )

    agg_result = await db.execute(
        text(
            f"""
            SELECT
                COUNT(*) AS listing_count,
                MIN(price) AS min_price,
                MAX(price) AS max_price,
                PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY price) AS median_price
            FROM (
                SELECT price FROM gem_radar_cpk_listing_price
                WHERE cpk = :cpk
                  AND updated_at >= CURRENT_TIMESTAMP - INTERVAL '{MARKET_PRICE_WINDOW_DAYS} days'
                UNION ALL
                SELECT price FROM gem_radar_sold_observations
                WHERE cpk = :cpk
                  AND observed_at >= CURRENT_TIMESTAMP - INTERVAL '{MARKET_PRICE_WINDOW_DAYS} days'
                UNION ALL
                SELECT price FROM gem_radar_amazon_observations
                WHERE cpk = :cpk
                  AND observed_at >= CURRENT_TIMESTAMP - INTERVAL '{MARKET_PRICE_WINDOW_DAYS} days'
                UNION ALL
                SELECT price FROM gem_radar_scan_observation
                WHERE cpk = :cpk
                  AND observed_at >= CURRENT_TIMESTAMP - INTERVAL '{MARKET_PRICE_WINDOW_DAYS} days'
            ) AS all_prices
            """
        ),
        {"cpk": cpk},
    )
    row = agg_result.fetchone()
    listing_count, min_price, max_price, median_price = row[0], row[1], row[2], row[3]

    await db.execute(
        text(
            """
            INSERT INTO gem_radar_cpk_market_price
                (cpk, category, brand, model, min_price, median_price, max_price, listing_count, updated_at)
            VALUES
                (:cpk, :category, :brand, :model, :min_price, :median_price, :max_price, :listing_count, CURRENT_TIMESTAMP)
            ON CONFLICT (cpk) DO UPDATE SET
                category = COALESCE(EXCLUDED.category, gem_radar_cpk_market_price.category),
                brand = COALESCE(EXCLUDED.brand, gem_radar_cpk_market_price.brand),
                model = COALESCE(EXCLUDED.model, gem_radar_cpk_market_price.model),
                min_price = EXCLUDED.min_price,
                median_price = EXCLUDED.median_price,
                max_price = EXCLUDED.max_price,
                listing_count = EXCLUDED.listing_count,
                updated_at = CURRENT_TIMESTAMP
            """
        ),
        {
            "cpk": cpk,
            "category": category,
            "brand": brand,
            "model": model,
            "min_price": min_price,
            "median_price": median_price,
            "max_price": max_price,
            "listing_count": listing_count,
        },
    )


async def get_market_price(db: AsyncSession, cpk: str) -> CPKMarketPrice | None:
    """Returns the CPK's aggregate price over the rolling
    MARKET_PRICE_WINDOW_DAYS window, or None if fewer than
    MIN_LISTINGS_FOR_SETTLED_PRICE listings within that window have
    contributed to it — callers must never classify against an unsettled
    price.

    Recomputes live against gem_radar_cpk_listing_price rather than reading
    the gem_radar_cpk_market_price cache table directly: that cache only
    updates when a NEW listing arrives for this cpk (see
    upsert_listing_price), so if a CPK's last contributing listing simply
    ages out of the window with no new sighting, the cached row would keep
    reporting a stale, no-longer-valid aggregate indefinitely.
    """
    result = await db.execute(
        text(
            f"""
            SELECT
                MIN(price) AS min_price,
                MAX(price) AS max_price,
                PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY price) AS median_price,
                COUNT(*) AS listing_count
            FROM (
                SELECT price FROM gem_radar_cpk_listing_price
                WHERE cpk = :cpk
                  AND updated_at >= CURRENT_TIMESTAMP - INTERVAL '{MARKET_PRICE_WINDOW_DAYS} days'
                UNION ALL
                SELECT price FROM gem_radar_sold_observations
                WHERE cpk = :cpk
                  AND observed_at >= CURRENT_TIMESTAMP - INTERVAL '{MARKET_PRICE_WINDOW_DAYS} days'
                UNION ALL
                SELECT price FROM gem_radar_amazon_observations
                WHERE cpk = :cpk
                  AND observed_at >= CURRENT_TIMESTAMP - INTERVAL '{MARKET_PRICE_WINDOW_DAYS} days'
                UNION ALL
                SELECT price FROM gem_radar_scan_observation
                WHERE cpk = :cpk
                  AND observed_at >= CURRENT_TIMESTAMP - INTERVAL '{MARKET_PRICE_WINDOW_DAYS} days'
            ) AS all_prices
            """
        ),
        {"cpk": cpk},
    )
    row = result.fetchone()
    if row is None:
        return None

    min_price, max_price, median_price, listing_count = row[0], row[1], row[2], row[3]
    if listing_count < MIN_LISTINGS_FOR_SETTLED_PRICE:
        return None
    if min_price is None or median_price is None or max_price is None:
        return None

    return CPKMarketPrice(
        cpk=cpk,
        min_price=min_price,
        median_price=median_price,
        max_price=max_price,
        listing_count=listing_count,
    )


async def get_market_price_with_hierarchy_fallback(
    db: AsyncSession, cpk: str
) -> CPKMarketPrice | None:
    """Returns market price for a CPK, falling back to broader category levels
    if the specific CPK doesn't have enough observations to settle.

    For now, returns exact CPK price if settled, or None.
    Hierarchy fallback (category-level pricing) deferred to Phase 3 after
    cpk_data stability verified — complex JSONB joins present early risks.
    """
    return await get_market_price(db, cpk)
